/**
 * molique - Navbar Active (highlighting the current page based on the URL)
 *
 * The top navbar is shared across subpages (a single markup), so the active item can't
 * be marked statically in the HTML. This module reads the URL and applies .is-active to
 * the current page's link AND to the trigger of the dropdown menu (dropdown /
 * mega-menu) that link is located in.
 *
 * When a page appears in several menus at once (e.g. in the "Examples" dropdown and in
 * the "Components" mega menu), all of its occurrences are highlighted.
 *
 * Zero dependencies. Auto-loaded by molique-script.js when .navbar-menu is present.
 */
function initNavbarActive() {
  const menu = document.querySelector('.navbar-menu');
  if (!menu) return;

  const here = normalizeNavPath(location.pathname);
  const links = menu.querySelectorAll(
    '.navbar-item[href], .dropdown-item[href], .mega-menu-link[href], .mega-menu-featured-link[href]'
  );

  links.forEach((link) => {
    const raw = link.getAttribute('href');
    // We skip anchors (#...) and full URLs with a protocol (http:, mailto:, tel:).
    if (!raw || raw.charAt(0) === '#' || /^[a-z][a-z0-9+.-]*:/i.test(raw)) return;

    let linkPath;
    try {
      linkPath = normalizeNavPath(new URL(raw, location.href).pathname);
    } catch (e) {
      return;
    }
    if (linkPath !== here) return;

    link.classList.add('is-active');

    // The trigger of the dropdown menu the active link lies in.
    const parent = link.closest('.dropdown, .mega-menu');
    if (parent) {
      const trigger = parent.querySelector(':scope > summary');
      if (trigger) trigger.classList.add('is-active');
    }
  });
}

/* Normalizes the path for comparison: no trailing slash; "" and "/index.html" => "/"
   (homepage). Named differently from normalizePath in admin-nav.js to avoid global
   function collisions on shared pages. */
function normalizeNavPath(pathname) {
  const p = pathname.replace(/\/+$/, '');
  if (p === '' || p === '/index.html') return '/';
  return p;
}

window.initNavbarActive = initNavbarActive;
