/**
 * molique - Admin Nav Active (highlighting the current page in the sidebar)
 *
 * The counterpart to molique-navbar-active.js for the admin panel's vertical menu. The
 * sidebar is often shared across subpages (a single partial), so the active position
 * cannot be marked statically in the markup - the module reads the URL and assigns
 * .is-active to the current page's links.
 *
 * Highlights ALL occurrences of the address, since the same position usually appears
 * twice: in the condensed mobile bar (.mobile-only-nav-item) and in the full list
 * inside the "More" drawer.
 *
 * Separation of concerns: expandable <details class="admin-nav-submenu"> branches are
 * handled by molique-admin-nav.js (there, activity is coupled with the mobile
 * drill-down). This module handles only flat links.
 *
 * Zero dependencies. Auto-loaded by molique-script.js when .admin-nav is present.
 */
function initAdminNavActive() {
  const navs = document.querySelectorAll('.admin-nav');
  if (!navs.length) return;

  const here = normalizeAdminNavPath(location.pathname);

  navs.forEach((nav) => {
    nav.querySelectorAll('.admin-nav-link[href]').forEach((link) => {
      // Submenu items are left to molique-admin-nav.js - otherwise two modules would
      // fight over the same element (and over the branch's expanded state).
      if (link.closest('.admin-nav-submenu')) return;

      const raw = link.getAttribute('href');
      // We skip anchors (#...) and full URLs with a protocol (http:, mailto:).
      if (!raw || raw.charAt(0) === '#' || /^[a-z][a-z0-9+.-]*:/i.test(raw)) return;

      let linkPath;
      try {
        linkPath = normalizeAdminNavPath(new URL(raw, location.href).pathname);
      } catch (e) {
        return;
      }

      if (linkPath === here) link.classList.add('is-active');
    });
  });
}

/* Normalizes the path for comparison: no trailing slash; "" and "/index.html" => "/"
   (home page). The name differs from normalizePath in admin-nav.js and normalizeNavPath
   in navbar-active.js, to avoid a collision between global functions on pages that load
   several modules. */
function normalizeAdminNavPath(pathname) {
  const p = pathname.replace(/\/+$/, '');
  if (p === '' || p === '/index.html') return '/';
  return p;
}

window.initAdminNavActive = initAdminNavActive;
