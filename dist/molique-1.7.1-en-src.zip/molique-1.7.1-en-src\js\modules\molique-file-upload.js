/**
 * molique - Custom File Upload (preview of the selected file's name)
 *
 * .file-upload rests on an invisible input[type="file"] stretched across the whole zone
 * (position:absolute, opacity:0) - thanks to this, clicking and dragging a file both
 * work natively without extra code. This module adds the only missing piece:
 * confirmation that a file was selected. Without it, the input silently accepts the
 * file (a drop also doesn't open it as a new browser tab), but nothing shows for it.
 */
function initFileUpload() {
  document.querySelectorAll('.file-upload input[type="file"]').forEach((input) => {
    const box = input.closest('.file-upload');
    if (!box) return;

    input.addEventListener('change', () => {
      const files = input.files;
      if (!files || files.length === 0) return;

      let nameEl = box.querySelector('.file-upload-name');
      if (!nameEl) {
        nameEl = document.createElement('p');
        nameEl.className = 'file-upload-name text-4 fw-bold m-0 mt-2';
        box.appendChild(nameEl);
      }

      nameEl.textContent = files.length === 1
        ? files[0].name
        : `Wybrano ${files.length} plików`;
    });
  });
}

window.initFileUpload = initFileUpload;
