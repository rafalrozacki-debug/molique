/**
 * molique - Table Live Search Filters table rows based on the entered text. Initialized
 * by the autoloader (initTableSearch)
 */

window.initTableSearch = function() {
  // We look for all inputs with the data-search-target attribute
  const searchInputs = document.querySelectorAll('input[data-search-target]');

  searchInputs.forEach(input => {
    // We get the ID of the table this input is meant to filter
    const targetId = input.getAttribute('data-search-target');
    const tableBody = document.querySelector(targetId);

    if (!tableBody) return;

    // We get all data rows (skipping category headers)
    const rows = tableBody.querySelectorAll('tr:not(.cheat-sheet-category)');

    input.addEventListener('input', function(e) {
      const searchTerm = e.target.value.toLowerCase().trim();

      rows.forEach(row => {
        // We get the full text of the row
        const rowText = row.textContent.toLowerCase();

        // If the text contains the search phrase, we show the row, otherwise we hide it
        if (rowText.includes(searchTerm)) {
          row.style.display = '';
        } else {
          row.style.display = 'none';
        }
      });

      // Optional: hiding category headers if all of their children are hidden (for
      // advanced tables such as our Cheat Sheet)
      const categories = tableBody.querySelectorAll('tr.cheat-sheet-category');
      categories.forEach(category => {
        let nextRow = category.nextElementSibling;
        let hasVisibleChildren = false;

        // We check all rows up to the next category
        while (nextRow && !nextRow.classList.contains('cheat-sheet-category')) {
          if (nextRow.style.display !== 'none') {
            hasVisibleChildren = true;
            break;
          }
          nextRow = nextRow.nextElementSibling;
        }

        // We hide the category if it has no results underneath it
        category.style.display = hasVisibleChildren ? '' : 'none';
      });
    });
  });
};