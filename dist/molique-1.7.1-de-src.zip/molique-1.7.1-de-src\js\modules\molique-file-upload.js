/**
 * molique - Custom File Upload (Vorschau des ausgewählten Dateinamens)
 *
 * .file-upload beruht auf einem unsichtbaren input[type="file"], das über die gesamte
 * Zone gespannt ist (position:absolute, opacity:0) - dadurch funktionieren Klick und
 * Datei-Drag-and-Drop nativ, ohne zusätzlichen Code. Dieses Modul ergänzt den einzigen
 * fehlenden Teil: die Bestätigung, dass eine Datei ausgewählt wurde. Ohne es nimmt das
 * Input die Datei stillschweigend an (ein Drop öffnet sie auch nicht als neuen
 * Browser-Tab), zeigt davon aber nichts an.
 */
function initFileUpload() {
  document.querySelectorAll('.file-upload input[type="file"]').forEach((input) => {
    const box = input.closest('.file-upload');
    if (!box) return;

    input.addEventListener('change', () => {
      const files = input.files;
      if (!files || files.length === 0) return;

      let nameEl = box.querySelector('.file-upload-name');
      if (!nameEl) {
        nameEl = document.createElement('p');
        nameEl.className = 'file-upload-name text-4 fw-bold m-0 mt-2';
        box.appendChild(nameEl);
      }

      nameEl.textContent = files.length === 1
        ? files[0].name
        : `Wybrano ${files.length} plików`;
    });
  });
}

window.initFileUpload = initFileUpload;
