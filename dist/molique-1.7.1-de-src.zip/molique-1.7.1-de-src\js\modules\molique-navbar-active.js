/**
 * molique - Navbar Active (Hervorhebung der aktuellen Seite anhand der URL)
 *
 * Die obere Navbar wird von den Unterseiten gemeinsam genutzt (ein einziges Markup),
 * daher lässt sich die aktive Position nicht statisch im HTML markieren. Dieses Modul
 * liest die URL aus und vergibt .is-active an den Link der aktuellen Seite SOWIE an den
 * Trigger des aufklappbaren Menüs (Dropdown/Mega-Menü), in dem sich dieser Link
 * befindet.
 *
 * Erscheint eine Seite gleichzeitig in mehreren Menüs (z. B. im Dropdown „Beispiele"
 * und im Mega-Menü „Komponenten"), werden alle ihre Vorkommen hervorgehoben.
 *
 * Keine Abhängigkeiten. Wird von molique-script.js automatisch geladen, wenn
 * .navbar-menu vorhanden ist.
 */
function initNavbarActive() {
  const menu = document.querySelector('.navbar-menu');
  if (!menu) return;

  const here = normalizeNavPath(location.pathname);
  const links = menu.querySelectorAll(
    '.navbar-item[href], .dropdown-item[href], .mega-menu-link[href], .mega-menu-featured-link[href]'
  );

  links.forEach((link) => {
    const raw = link.getAttribute('href');
    // Wir überspringen Anker (#...) sowie vollständige URLs mit Protokoll (http:,
    // mailto:, tel:).
    if (!raw || raw.charAt(0) === '#' || /^[a-z][a-z0-9+.-]*:/i.test(raw)) return;

    let linkPath;
    try {
      linkPath = normalizeNavPath(new URL(raw, location.href).pathname);
    } catch (e) {
      return;
    }
    if (linkPath !== here) return;

    link.classList.add('is-active');

    // Der Trigger des aufklappbaren Menüs, in dem sich der aktive Link befindet.
    const parent = link.closest('.dropdown, .mega-menu');
    if (parent) {
      const trigger = parent.querySelector(':scope > summary');
      if (trigger) trigger.classList.add('is-active');
    }
  });
}

/* Normalisiert den Pfad für den Vergleich: ohne abschließenden Slash; "" und
   "/index.html" => "/" (Startseite). Anders benannt als normalizePath in admin-nav.js,
   um Kollisionen globaler Funktionen auf gemeinsam genutzten Seiten zu vermeiden. */
function normalizeNavPath(pathname) {
  const p = pathname.replace(/\/+$/, '');
  if (p === '' || p === '/index.html') return '/';
  return p;
}

window.initNavbarActive = initNavbarActive;
