/**
 * molique - Admin Nav Active (Hervorhebung der aktuellen Seite in der Seitenleiste)
 *
 * Das Gegenstück zu molique-navbar-active.js für das vertikale Menü des Admin-Panels.
 * Die Seitenleiste wird oft von mehreren Unterseiten gemeinsam genutzt (ein einziges
 * Partial), sodass die aktive Position nicht statisch im Markup markiert werden kann -
 * das Modul liest die URL aus und weist .is-active den Links der aktuellen Seite zu.
 *
 * Hebt ALLE Vorkommen der Adresse hervor, da dieselbe Position üblicherweise zweimal
 * auftaucht: in der verkürzten mobilen Leiste (.mobile-only-nav-item) und in der
 * vollständigen Liste in der Schublade „Mehr".
 *
 * Trennung der Zuständigkeiten: aufklappbare <details class="admin-nav-submenu">-Zweige
 * werden von molique-admin-nav.js verwaltet (dort ist die Aktivität mit dem mobilen
 * Drill-down gekoppelt). Dieses Modul kümmert sich ausschließlich um flache Links.
 *
 * Keine Abhängigkeiten. Wird von molique-script.js automatisch geladen, sobald
 * .admin-nav vorhanden ist.
 */
function initAdminNavActive() {
  const navs = document.querySelectorAll('.admin-nav');
  if (!navs.length) return;

  const here = normalizeAdminNavPath(location.pathname);

  navs.forEach((nav) => {
    nav.querySelectorAll('.admin-nav-link[href]').forEach((link) => {
      // Positionen im Untermenü überlassen wir molique-admin-nav.js - andernfalls
      // würden zwei Module um dasselbe Element (und um den Aufklappzustand des Zweigs)
      // konkurrieren.
      if (link.closest('.admin-nav-submenu')) return;

      const raw = link.getAttribute('href');
      // Wir überspringen Anker (#...) sowie vollständige URLs mit Protokoll (http:,
      // mailto:).
      if (!raw || raw.charAt(0) === '#' || /^[a-z][a-z0-9+.-]*:/i.test(raw)) return;

      let linkPath;
      try {
        linkPath = normalizeAdminNavPath(new URL(raw, location.href).pathname);
      } catch (e) {
        return;
      }

      if (linkPath === here) link.classList.add('is-active');
    });
  });
}

/* Vereinheitlicht den Pfad für den Vergleich: ohne abschließenden Schrägstrich; "" und
   "/index.html" => "/" (Startseite). Der Name unterscheidet sich von normalizePath in
   admin-nav.js und normalizeNavPath in navbar-active.js, um eine Kollision globaler
   Funktionen auf Seiten zu vermeiden, die mehrere Module laden. */
function normalizeAdminNavPath(pathname) {
  const p = pathname.replace(/\/+$/, '');
  if (p === '' || p === '/index.html') return '/';
  return p;
}

window.initAdminNavActive = initAdminNavActive;
