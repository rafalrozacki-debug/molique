/**
 * molique - Admin Nav (Submenü-Aktivität + mobiler Drill-down)
 *
 * Ein wenig Vanilla-JS rund um das native <details class="admin-nav-submenu">: -
 * erkennt die aktive Position anhand der URL und hebt sie sowie ihren Zweig mit der
 * Klasse .is-active hervor (kein [open]-Attribut im Markup nötig), - verhindert auf
 * Mobilgeräten, dass sich der aktive Zweig beim Start automatisch als Drill-down öffnet
 * (das war das Hauptärgernis: Aufruf einer Unterseite = bereits geöffnetes Panel), -
 * animiertes Schließen (Ausfahren nach unten): das native <details> blendet den Inhalt
 * sofort aus, daher verzögern wir das Entfernen von [open] um die Dauer der
 * CSS-Animation, - gegenseitiger Ausschluss: das Öffnen eines Submenüs schließt die
 * übrigen, - Esc schließt einen offenen Drill-down, ebenso ein Wechsel des Breakpoints.
 *
 * Öffnen und Einfahren übernehmen das native <details> + CSS. Keine Abhängigkeiten.
 */
function initAdminNav() {
  const submenus = Array.from(document.querySelectorAll('.admin-nav-submenu'));
  if (!submenus.length) return;

  const mobile = window.matchMedia('(max-width: 768px)');
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const here = normalizePath(location.pathname);

  // Animiertes Schließen: spielt das Ausfahren ab (.is-closing) und entfernt danach
  // [open]. Auf dem Desktop und bei reduced-motion schließt es sofort.
  const closeAnimated = (details) => {
    if (!details.open) return;
    if (!mobile.matches || reduceMotion.matches) {
      details.open = false;
      return;
    }
    if (details.classList.contains('is-closing')) return;

    const panel = details.querySelector(':scope > .admin-nav-submenu-list');
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      // Zuerst [open]=false (natives Ausblenden), erst danach .is-closing entfernen -
      // sonst würde dazwischen die Einfahranimation aufblitzen.
      details.open = false;
      details.classList.remove('is-closing');
    };

    details.classList.add('is-closing');
    if (panel) {
      panel.addEventListener('animationend', finish, { once: true });
      // Eine Absicherung für den Fall, dass animationend nicht auslöst (z. B. ein Panel
      // ohne Animation).
      setTimeout(finish, 400);
    } else {
      finish();
    }
  };

  submenus.forEach((details) => {
    const summary = details.querySelector(':scope > summary');
    const list = details.querySelector(':scope > .admin-nav-submenu-list');
    if (!summary || !list) return;

    // 1. Aktivität aus der URL - aktiven Link und dessen Zweig hervorheben.
    let hasActive = false;
    list.querySelectorAll('.admin-nav-submenu-link').forEach((link) => {
      const raw = link.getAttribute('href');
      if (!raw || raw.charAt(0) === '#') return;

      let linkPath;
      try {
        linkPath = normalizePath(new URL(raw, location.href).pathname);
      } catch (e) {
        return;
      }

      if (linkPath === here) {
        link.classList.add('is-active');
        hasActive = true;
      }
    });
    if (hasActive) {
      summary.classList.add('is-active');
      // Auf dem Desktop (Baumansicht) soll sich der Zweig mit der aktuellen Seite von
      // selbst öffnen - ohne das würde der Nutzer die Seite laden, ohne zu sehen, wo er
      // im Menü steht. Schritt 2 weiter unten schließt dies auf Mobilgeräten
      // (Drill-down) ohnehin sofort wieder, daher ist hier keine Viewport-Bedingung
      // nötig.
      details.open = true;
    }

    // 2. Auf Mobilgeräten den Drill-down beim Start nicht automatisch öffnen. Rendert
    // das Markup <details open> für den aktiven Zweig, behalten wir die Kennzeichnung
    // über .is-active bei, schließen das Panel aber (ohne Animation - dies ist der
    // Startzustand).
    if (mobile.matches && details.open) {
      summary.classList.add('is-active');
      details.open = false;
    }

    // 3. Schließen über die Leiste "Cofnij": Wir übernehmen den nativen Toggle, um das
    // Ausfahren abzuspielen. Das Öffnen überlassen wir dem nativen <details> (Einfahren
    // per CSS).
    summary.addEventListener('click', (e) => {
      if (mobile.matches && details.open && !details.classList.contains('is-closing')) {
        e.preventDefault();
        closeAnimated(details);
      }
    });

    // 4. Gegenseitiger Ausschluss (nur auf Mobilgeräten) - das Öffnen eines Elements
    // schließt die anderen (sofort; das "fremde" Panel wird nicht animiert).
    details.addEventListener('toggle', () => {
      if (!details.open || !mobile.matches) return;
      submenus.forEach((other) => {
        if (other !== details && other.open) other.open = false;
      });
    });
  });

  // 5. Esc schließt einen offenen Drill-down (mit Ausfahranimation).
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    submenus.forEach((details) => {
      if (details.open) closeAnimated(details);
    });
  });

  // 6. Breakpoint-Wechsel - wir schließen geöffnete Panels sofort, um bei
  // Bildschirmdrehung/Breitenänderung kein hängen gebliebenes Drill-down-Panel zu
  // hinterlassen.
  const closeAll = () => submenus.forEach((details) => {
    details.classList.remove('is-closing');
    details.open = false;
  });
  if (mobile.addEventListener) {
    mobile.addEventListener('change', closeAll);
  } else if (mobile.addListener) {
    mobile.addListener(closeAll); // ältere Safari-Versionen
  }
}

/* Normalisiert den Pfad für den Vergleich: ohne abschließenden Slash, leer => "/". */
function normalizePath(pathname) {
  return pathname.replace(/\/+$/, '') || '/';
}

window.initAdminNav = initAdminNav;
