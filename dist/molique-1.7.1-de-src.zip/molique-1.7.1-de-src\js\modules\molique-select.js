/**
 * molique - Searchable-Select-Modul (Combobox)
 *
 * Das Menü ist ein Popover (Popover API, Top Layer) - das Öffnen über den
 * [popovertarget]-Button sowie das Schließen mit Esc und per Klick außerhalb des Menüs
 * (Light Dismiss) übernimmt der Browser nativ. JS ist ausschließlich zuständig für: das
 * Filtern der Optionen, die Behandlung der Auswahl und das Schreiben des Werts in das
 * versteckte Feld für das Backend.
 *
 * Abwärtskompatibilität: Auf <details class="select-search"> basierendes Markup
 * (Versionen vor 1.5.0) wird weiterhin unterstützt - dabei erfolgt das Schließen durch
 * Entfernen des Attributs [open] und das Abhören von Klicks außerhalb der Komponente.
 *
 * Event-Delegation (input/click auf document) statt Listener pro Option beim Start
 * anzuhängen: funktioniert auch für Optionen, die dem DOM NACH dem Laden der Seite
 * hinzugefügt werden (z. B. ein Kalender, der per AJAX eine Kundenliste nachlädt) -
 * ohne das müsste das Modul nach jeder solchen Änderung manuell neu initialisiert
 * werden.
 */
document.addEventListener('input', (e) => {
  const searchInput = e.target.closest('.select-search-input');
  if (!searchInput) return;

  const select = searchInput.closest('.select-search');
  if (!select) return;

  const term = searchInput.value.toLowerCase();
  select.querySelectorAll('.select-search-option').forEach(option => {
    option.classList.toggle('is-hidden', !option.textContent.toLowerCase().includes(term));
  });
});

document.addEventListener('click', (e) => {
  const option = e.target.closest('.select-search-option');
  if (!option) return;

  const select = option.closest('.select-search');
  if (!select) return;

  const menu = select.querySelector('.select-search-menu');
  const trigger = select.querySelector('.select-search-trigger span');
  const searchInput = select.querySelector('.select-search-input');
  const hiddenInput = select.querySelector('.select-search-hidden');
  const isPopover = !!(menu && menu.hasAttribute('popover'));

  if (trigger) {
    trigger.textContent = option.textContent.trim();
    trigger.style.color = 'var(--text-main)';
  }
  if (hiddenInput) {
    hiddenInput.value = option.getAttribute('data-value') || '';
    hiddenInput.dispatchEvent(new Event('change', { bubbles: true }));
  }

  select.querySelectorAll('.select-search-option').forEach(opt => opt.classList.remove('is-selected'));
  option.classList.add('is-selected');

  if (isPopover) {
    menu.hidePopover();
  } else {
    select.removeAttribute('open');
  }

  if (searchInput) {
    searchInput.value = '';
    select.querySelectorAll('.select-search-option').forEach(opt => opt.classList.remove('is-hidden'));
  }
});

// Fokus auf das Suchfeld direkt nach dem Öffnen des Menüs (Popover API) - das
// toggle-Ereignis bubbelt nicht, daher erfordert die Delegation die Capturing-Phase.
document.addEventListener('toggle', (e) => {
  const menu = e.target;
  if (!menu.classList || !menu.classList.contains('select-search-menu')) return;
  if (e.newState !== 'open') return;

  const searchInput = menu.querySelector('.select-search-input');
  if (searchInput) searchInput.focus({ preventScroll: true });
}, true);

// Das alte <details>-Markup (ohne [popover]-Attribut am Menü) hat kein natives Light
// Dismiss - das Schließen bei Klick außerhalb der Komponente muss manuell behandelt
// werden.
document.addEventListener('click', (e) => {
  document.querySelectorAll('.select-search[open]').forEach(select => {
    const menu = select.querySelector('.select-search-menu');
    if (menu && menu.hasAttribute('popover')) return; // neues Markup - [open] hier ungenutzt
    if (!select.contains(e.target)) select.removeAttribute('open');
  });
});

/**
 * Das Setzen des Werts aus JS heraus (z. B. beim Öffnen eines Bearbeiten-Modals mit den
 * Daten eines bestimmten Datensatzes) - synchronisiert das Label am Button und die
 * Hervorhebung der gewählten Option, genau wie bei der Auswahl per Maus. Nimmt das
 * <input type="hidden"> des jeweiligen .select-search selbst entgegen.
 */
window.MoliqueSelectSearch = {
  setValue(hiddenInput, value) {
    if (!hiddenInput) return;
    const select = hiddenInput.closest('.select-search');
    if (!select) return;

    const trigger = select.querySelector('.select-search-trigger');
    const label = trigger ? trigger.querySelector('span') : null;
    const option = select.querySelector(`.select-search-option[data-value="${CSS.escape(String(value))}"]`);

    hiddenInput.value = option ? value : '';

    select.querySelectorAll('.select-search-option').forEach(opt => opt.classList.remove('is-selected'));
    if (option) {
      option.classList.add('is-selected');
      if (label) label.textContent = option.textContent.trim();
    } else if (label) {
      label.textContent = (trigger && trigger.dataset.placeholder) || label.textContent;
    }
  }
};
