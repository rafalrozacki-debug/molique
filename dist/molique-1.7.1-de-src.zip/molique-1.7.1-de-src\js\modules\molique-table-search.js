/**
 * molique - Table Live Search Filtert Tabellenzeilen anhand des eingegebenen Texts.
 * Wird vom Autoloader initialisiert (initTableSearch)
 */

window.initTableSearch = function() {
  // Wir suchen alle Inputs mit dem Attribut data-search-target
  const searchInputs = document.querySelectorAll('input[data-search-target]');

  searchInputs.forEach(input => {
    // Wir ermitteln die ID der Tabelle, die dieses Input filtern soll
    const targetId = input.getAttribute('data-search-target');
    const tableBody = document.querySelector(targetId);

    if (!tableBody) return;

    // Wir ermitteln alle Datenzeilen (Kategorie-Überschriften werden übersprungen)
    const rows = tableBody.querySelectorAll('tr:not(.cheat-sheet-category)');

    input.addEventListener('input', function(e) {
      const searchTerm = e.target.value.toLowerCase().trim();

      rows.forEach(row => {
        // Wir ermitteln den gesamten Text der Zeile
        const rowText = row.textContent.toLowerCase();

        // Enthält der Text die gesuchte Phrase, zeigen wir die Zeile, andernfalls
        // blenden wir sie aus
        if (rowText.includes(searchTerm)) {
          row.style.display = '';
        } else {
          row.style.display = 'none';
        }
      });

      // Optional: Ausblenden von Kategorie-Überschriften, wenn alle ihre
      // untergeordneten Elemente ausgeblendet sind (für erweiterte Tabellen wie unser
      // Cheat Sheet)
      const categories = tableBody.querySelectorAll('tr.cheat-sheet-category');
      categories.forEach(category => {
        let nextRow = category.nextElementSibling;
        let hasVisibleChildren = false;

        // Wir prüfen alle Zeilen bis zur nächsten Kategorie
        while (nextRow && !nextRow.classList.contains('cheat-sheet-category')) {
          if (nextRow.style.display !== 'none') {
            hasVisibleChildren = true;
            break;
          }
          nextRow = nextRow.nextElementSibling;
        }

        // Wir blenden die Kategorie aus, wenn sich darunter keine Ergebnisse befinden
        category.style.display = hasVisibleChildren ? '' : 'none';
      });
    });
  });
};