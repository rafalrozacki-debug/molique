/**
 * molique - Lang Suggest (Sprachwechsel-Vorschlag basierend auf navigator.language)
 *
 * Es leitet nicht zwangsweise um - Google rät von automatischen Sprachweiterleitungen
 * ab (sie können den Googlebot, der sich als en-US meldet, von der polnischen Version
 * abschneiden und die Sichtbarkeit schädigen). Stattdessen ein dezenter, schließbarer
 * Balken am unteren Bildschirmrand, in der beim Nutzer ERKANNTEN Sprache - nicht in der
 * Sprache der Seite, auf der er sich gerade befindet.
 *
 * Das Linkziel wird aus dem bereits vorhandenen .language-switch-menu in der Navbar
 * entnommen (Attribut data-lang an jedem .language-switch-item) - keine Duplizierung
 * der Logik "hat diese Seite eine EN/DE-Version", die computeI18nLocals in
 * vite.config.js bereits berechnet. Seiten ohne Navbar (z. B. docs-classes.html)
 * besitzen kein .language-switch-menu, weshalb das Modul dort überhaupt nicht
 * nachgeladen wird (siehe dynamicModules in molique-script.js).
 *
 * Die Entscheidung des Nutzers (wechseln/bleiben) wird in localStorage gespeichert -
 * der Balken wird nur einmal angezeigt. Wird automatisch geladen, wenn
 * .language-switch-menu vorhanden ist.
 */
const LANG_SUGGEST_DISMISSED_KEY = "molique-lang-suggest-dismissed";

const LANG_SUGGEST_MESSAGES = {
  pl: {
    text: "Czy chcesz przeczytać tę stronę po polsku?",
    switch: "Tak, przełącz",
    stay: "Zostań przy tej wersji",
  },
  en: {
    text: "Would you like to read this page in English?",
    switch: "Yes, switch",
    stay: "Stay on this version",
  },
  de: {
    text: "Möchtest du diese Seite auf Deutsch lesen?",
    switch: "Ja, wechseln",
    stay: "Bei dieser Version bleiben",
  },
};

function initLangSuggest() {
  if (localStorage.getItem(LANG_SUGGEST_DISMISSED_KEY)) return;

  const detected = detectLangSuggestLocale();
  if (!detected) return;

  const current = document.documentElement.lang;
  if (detected === current) return;

  const menu = document.querySelector(".language-switch-menu");
  if (!menu) return;

  const targetLink = menu.querySelector(`[data-lang="${detected}"]`);
  if (!targetLink) return;

  showLangSuggestBar(LANG_SUGGEST_MESSAGES[detected], targetLink.getAttribute("href"));
}

function detectLangSuggestLocale() {
  const raw = navigator.language || (navigator.languages && navigator.languages[0]) || "";
  const code = raw.slice(0, 2).toLowerCase();
  return LANG_SUGGEST_MESSAGES[code] ? code : null;
}

function showLangSuggestBar(messages, href) {
  const bar = document.createElement("div");
  bar.className = "lang-suggest-bar";
  bar.innerHTML = `
    <p class="lang-suggest-text">${messages.text}</p>
    <div class="lang-suggest-actions">
      <button type="button" class="btn-primary btn-sm" data-action="switch">${messages.switch}</button>
      <button type="button" class="btn-outline-secondary btn-sm" data-action="stay">${messages.stay}</button>
    </div>
  `;

  bar.querySelector('[data-action="switch"]').addEventListener("click", () => {
    dismissLangSuggest(bar);
    location.href = href;
  });
  bar.querySelector('[data-action="stay"]').addEventListener("click", () => {
    dismissLangSuggest(bar);
  });

  document.body.appendChild(bar);
  // Einblenden im nächsten Frame - das Element muss zunächst im Ausgangszustand
  // gerendert werden, damit der Übergang zu .is-visible tatsächlich animiert.
  requestAnimationFrame(() => bar.classList.add("is-visible"));
}

function dismissLangSuggest(bar) {
  localStorage.setItem(LANG_SUGGEST_DISMISSED_KEY, "1");
  bar.classList.remove("is-visible");
  // setTimeout statt transitionend - bei prefers-reduced-motion setzt CSS den Übergang
  // auf null, sodass transitionend nie auslösen würde.
  setTimeout(() => bar.remove(), 300);
}

window.initLangSuggest = initLangSuggest;
