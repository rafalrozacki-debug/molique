/**
 * r-lite - Skrypty komponentów (Modale, Navbar, Dropdown, Tabs, Accordion)
 */

// --- System Motywów (Dark Mode) ---
const themeToggle = document.getElementById('theme-toggle');
const rootEl = document.documentElement;

// 1. Sprawdź, czy użytkownik ma zapisany wybór, a jeśli nie - sprawdź system
const savedTheme = localStorage.getItem('rozacki-theme');
const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
const currentTheme = savedTheme ? savedTheme : (systemPrefersDark ? 'dark' : 'light');

// 2. Ustaw początkowy motyw na tagu <html> (od razu przy ładowaniu strony)
rootEl.setAttribute('data-theme', currentTheme);

// 3. Obsługa kliknięcia w przycisk
if (themeToggle) {
  themeToggle.addEventListener('click', () => {
    let theme = rootEl.getAttribute('data-theme');
    let newTheme = theme === 'dark' ? 'light' : 'dark';
    
    rootEl.setAttribute('data-theme', newTheme);
    localStorage.setItem('rozacki-theme', newTheme);
  });
}

// --- Modale ---
function toggleModal() {
  const modal = document.getElementById('exampleModal');
  if (modal) {
    modal.classList.toggle('is-active');
  }
}

document.addEventListener('DOMContentLoaded', () => {

  // --- Mobilny Navbar ---
  const navbarToggle = document.getElementById('navbarToggle');
  const navbarMenu = document.getElementById('navbarMenu');

  if (navbarToggle && navbarMenu) {
    navbarToggle.addEventListener('click', () => {
      navbarMenu.classList.toggle('is-active');
      navbarToggle.classList.toggle('is-active');
    });
  }

  // --- Dropdown ---
  const dropdownTrigger = document.getElementById('dropdownTrigger');
  const dropdownMenu = document.getElementById('dropdownMenu');

  if (dropdownTrigger && dropdownMenu) {
    dropdownTrigger.addEventListener('click', (e) => {
      e.preventDefault();
      dropdownMenu.classList.toggle('is-active');
    });

    document.addEventListener('click', (e) => {
      if (!dropdownTrigger.contains(e.target) && !dropdownMenu.contains(e.target)) {
        dropdownMenu.classList.remove('is-active');
      }
    });
  }

 // --- Zakładki (Tabs) ---
  const tabBtns = document.querySelectorAll('.tab-item, .tab-btn');

  if (tabBtns.length > 0) {
    tabBtns.forEach(btn => {
      btn.addEventListener('click', function() {
        const targetId = this.getAttribute('data-tab');

        // Znajdź kontener zawierający zarówno przyciski jak i panele
        let container = this.parentElement;
        while (container && !container.querySelector(`#${targetId}`)) {
          container = container.parentElement;
        }

        if (container) {
          // Usuń is-active ze wszystkich przycisków i pane'ów w kontenerze
          container.querySelectorAll('.tab-item, .tab-btn').forEach(b => b.classList.remove('is-active'));
          container.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('is-active'));

          // Dodaj is-active do klikniętego przycisku
          this.classList.add('is-active');

          // Pokaż target pane
          const targetPane = container.querySelector(`#${targetId}`);
          if (targetPane) {
            targetPane.classList.add('is-active');
          }
        }
      });
    });
  }

  // --- Akordion (Zwijane panele) ---
  const accordionHeaders = document.querySelectorAll('.accordion-header');

  accordionHeaders.forEach(header => {
    header.addEventListener('click', () => {
      const accordion = header.closest('.accordion');
      const allowMultiple = accordion && accordion.getAttribute('data-multiple') === 'true';
      const body = header.nextElementSibling;
      const isActive = header.classList.contains('is-active');

      if (!allowMultiple && !isActive) {
        const allHeaders = accordion.querySelectorAll('.accordion-header');
        allHeaders.forEach(h => {
          h.classList.remove('is-active');
          if (h.nextElementSibling) {
            h.nextElementSibling.classList.remove('is-active');
          }
        });
      }

      header.classList.toggle('is-active');
      if (body) {
        body.classList.toggle('is-active');
      }
    });
  });
	
  // --- Mega Menu ---
  const megaMenuTrigger = document.querySelector('.mega-menu-trigger');
  const megaMenuContent = document.querySelector('.mega-menu-content');

  if (megaMenuTrigger && megaMenuContent) {
    megaMenuTrigger.addEventListener('click', (e) => {
      e.preventDefault();
      megaMenuContent.classList.toggle('is-active');
    });
    
    document.addEventListener('click', (e) => {
      if (!megaMenuTrigger.contains(e.target) && !megaMenuContent.contains(e.target)) {
        megaMenuContent.classList.remove('is-active');
      }
    });
  }

  // --- Lightbox  ---
  const lightboxTriggers = document.querySelectorAll('[data-lightbox]');
  
  if (lightboxTriggers.length > 0) {
    const lightboxOverlay = document.createElement('div');
    lightboxOverlay.className = 'lightbox-overlay';
    lightboxOverlay.innerHTML = `
      <div class="lightbox-top-bar">
        <span class="lightbox-counter"></span>
        <button class="lightbox-close">&times;</button>
      </div>
      <button class="lightbox-nav lightbox-prev">&#10094;</button>
      <div class="lightbox-content">
        <img src="" alt="Powiększenie">
      </div>
      <button class="lightbox-nav lightbox-next">&#10095;</button>
    `;
    document.body.appendChild(lightboxOverlay);

    const lightboxImg = lightboxOverlay.querySelector('img');
    const lightboxClose = lightboxOverlay.querySelector('.lightbox-close');
    const btnPrev = lightboxOverlay.querySelector('.lightbox-prev');
    const btnNext = lightboxOverlay.querySelector('.lightbox-next');
    const counter = lightboxOverlay.querySelector('.lightbox-counter');

    let currentGallery = [];
    let currentIndex = 0;
    const galleries = {};

    // Grupowanie zdjęć
    lightboxTriggers.forEach(trigger => {
      const galleryName = trigger.getAttribute('data-gallery') || 'default';
      if (!galleries[galleryName]) galleries[galleryName] = [];
      galleries[galleryName].push(trigger);

      trigger.addEventListener('click', (e) => {
        e.preventDefault();
        currentGallery = galleries[galleryName];
        currentIndex = currentGallery.indexOf(trigger);
        updateLightbox();
        lightboxOverlay.classList.add('is-active');
      });
    });

    function updateLightbox() {
      const trigger = currentGallery[currentIndex];
      const imgUrl = trigger.getAttribute('href') || trigger.getAttribute('data-lightbox');
      lightboxImg.src = imgUrl;
      
      if (currentGallery.length > 1) {
        counter.textContent = `${currentIndex + 1} / ${currentGallery.length}`;
        btnPrev.style.display = 'block';
        btnNext.style.display = 'block';
        counter.style.display = 'block';
      } else {
        btnPrev.style.display = 'none';
        btnNext.style.display = 'none';
        counter.style.display = 'none';
      }
    }

    function showNext() {
      if (currentGallery.length <= 1) return;
      currentIndex = (currentIndex + 1) % currentGallery.length;
      updateLightbox();
    }

    function showPrev() {
      if (currentGallery.length <= 1) return;
      currentIndex = (currentIndex - 1 + currentGallery.length) % currentGallery.length;
      updateLightbox();
    }

    btnNext.addEventListener('click', (e) => { e.stopPropagation(); showNext(); });
    btnPrev.addEventListener('click', (e) => { e.stopPropagation(); showPrev(); });

    // Zamykanie
    const closeLightbox = () => lightboxOverlay.classList.remove('is-active');
    lightboxClose.addEventListener('click', closeLightbox);
    lightboxOverlay.addEventListener('click', (e) => {
      if (e.target === lightboxOverlay || e.target.classList.contains('lightbox-content')) closeLightbox();
    });

    // Klawiatura
    document.addEventListener('keydown', (e) => {
      if (!lightboxOverlay.classList.contains('is-active')) return;
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowRight') showNext();
      if (e.key === 'ArrowLeft') showPrev();
    });

    // Swipe dla urządzeń dotykowych
    let touchStartX = 0;
    let touchEndX = 0;
    lightboxOverlay.addEventListener('touchstart', e => {
      touchStartX = e.changedTouches[0].screenX;
    }, { passive: true });
    
    lightboxOverlay.addEventListener('touchend', e => {
      touchEndX = e.changedTouches[0].screenX;
      if (touchEndX < touchStartX - 50) showNext();
      if (touchEndX > touchStartX + 50) showPrev();
    }, { passive: true });
  }
	
	// --- Animacje wejścia (Intersection Observer) ---
  const animatedElements = document.querySelectorAll('.animate');

  if (animatedElements.length > 0) {
    const observer = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          // Dodaj klasę wyzwalającą animację
          entry.target.classList.add('is-visible');
          // Przestań obserwować (animacja wykonuje się tylko raz)
          observer.unobserve(entry.target);
        }
      });
    }, {
      root: null,
      rootMargin: '0px',
      threshold: 0.1 // Wyzwól, gdy 10% elementu pojawi się na ekranie
    });

    animatedElements.forEach(el => observer.observe(el));
  }
	
	// --- Smart Sticky Navbar ---
  const stickyNavbar = document.querySelector('.navbar-sticky');
  const mobileMenu = document.getElementById('navbarMenu'); // Pobieramy referencję do menu
  
  if (stickyNavbar) {
    let lastScrollY = window.scrollY;
    
    window.addEventListener('scroll', () => {
      const currentScrollY = window.scrollY;
      
      // Dodaj cień, jeśli zescrollowano poniżej 50px
      if (currentScrollY > 50) {
        stickyNavbar.classList.add('is-scrolled');
      } else {
        stickyNavbar.classList.remove('is-scrolled');
      }

      // SPRAWDZENIE: Czy menu mobilne jest otwarte?
      const isMenuOpen = mobileMenu && mobileMenu.classList.contains('is-active');

      // Ukryj menu przy scrollowaniu w dół (ale TYLKO jeśli menu mobilne jest zamknięte)
      if (currentScrollY > lastScrollY && currentScrollY > 100 && !isMenuOpen) {
        stickyNavbar.classList.add('is-hidden');
      } else {
        // Scroll w górę (lub menu jest otwarte) -> pokaż pasek
        stickyNavbar.classList.remove('is-hidden');
      }
      
      lastScrollY = currentScrollY;
    }, { passive: true });
  }
	
	// --- Karuzela ---
  const carousels = document.querySelectorAll('.carousel');

  carousels.forEach(carousel => {
    const track = carousel.querySelector('.carousel-track');
    const slides = Array.from(track.querySelectorAll('.carousel-slide'));
    const btnPrev = carousel.querySelector('.carousel-prev');
    const btnNext = carousel.querySelector('.carousel-next');
    
    // Tworzenie kontenera na kropki
    const dotsContainer = document.createElement('div');
    dotsContainer.className = 'carousel-dots';
    carousel.appendChild(dotsContainer);

    // Generowanie kropek
    slides.forEach((_, index) => {
      const dot = document.createElement('button');
      dot.className = 'carousel-dot';
      dot.setAttribute('aria-label', `Przejdź do slajdu ${index + 1}`);
      
      // Kliknięcie w kropkę przesuwa track do konkretnego slajdu
      dot.addEventListener('click', () => {
        const slideWidth = slides[0].getBoundingClientRect().width;
        track.scrollTo({ left: slideWidth * index, behavior: 'smooth' });
      });
      
      dotsContainer.appendChild(dot);
    });

    const dots = Array.from(dotsContainer.querySelectorAll('.carousel-dot'));

    // Obsługa strzałek
    if (btnNext) {
      btnNext.addEventListener('click', () => {
        const slideWidth = slides[0].getBoundingClientRect().width;
        track.scrollBy({ left: slideWidth, behavior: 'smooth' });
      });
    }

    if (btnPrev) {
      btnPrev.addEventListener('click', () => {
        const slideWidth = slides[0].getBoundingClientRect().width;
        track.scrollBy({ left: -slideWidth, behavior: 'smooth' });
      });
    }

    // Śledzenie aktywnego slajdu (Intersection Observer)
    // Zmienia aktywną kropkę, gdy slajd wejdzie w kadr co najmniej w 60%
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const slideIndex = slides.indexOf(entry.target);
          
          // Usuń is-active ze wszystkich kropek
          dots.forEach(dot => dot.classList.remove('is-active'));
          // Dodaj do aktualnej
          if (dots[slideIndex]) {
            dots[slideIndex].classList.add('is-active');
          }
        }
      });
    }, {
      root: track,
      threshold: 0.6 
    });

    slides.forEach(slide => observer.observe(slide));
  });
	
	// --- Word Rotator ---
  const wordRotators = document.querySelectorAll('.word-rotator');
  
  wordRotators.forEach(rotator => {
    const itemsContainer = rotator.querySelector('.word-rotator-items');
    if (!itemsContainer) return;
    
    const items = itemsContainer.querySelectorAll('span');
    if (items.length <= 1) return; // Brak sensu animować jedno słowo

    // Ustaw stałą wysokość rotatora na podstawie pierwszego słowa
    const firstItemHeight = items[0].offsetHeight;
    rotator.style.height = `${firstItemHeight}px`;

    let currentIndex = 0;

    setInterval(() => {
      currentIndex++;
      
      // Jeśli doszliśmy do końca, wracamy do początku
      if (currentIndex >= items.length) {
        currentIndex = 0;
        // Opcjonalnie: można tu wyłączyć transition na chwilę, żeby powrót był niewidoczny,
        // ale proste zapętlenie też wygląda świetnie.
      }
      
      // Przesunięcie o 100% wysokości pojedynczego słowa do góry
      itemsContainer.style.transform = `translateY(-${currentIndex * 100}%)`;
      
    }, 2500); // Słowo zmienia się co 2.5 sekundy
  });
	
	// --- Animowane Liczniki (Counters) ---
  const counters = document.querySelectorAll('.counter-value');
  
  if (counters.length > 0) {
    const counterObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const counter = entry.target;
          const target = parseFloat(counter.getAttribute('data-target'));
          const duration = 2000; // Czas animacji (2 sekundy)
          const startTime = performance.now();
          
          const prefix = counter.getAttribute('data-prefix') || '';
          const suffix = counter.getAttribute('data-suffix') || '';

          // Funkcja animująca klatka po klatce
          const updateCounter = (currentTime) => {
            const elapsedTime = currentTime - startTime;
            const progress = Math.min(elapsedTime / duration, 1);
            
            // Easing function: easeOutExpo (zwalnia pod koniec)
            const easeProgress = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
            
            const currentVal = target * easeProgress;
            
            // Formatowanie (jeśli to liczba całkowita, nie pokazuj miejsc po przecinku)
            const formattedVal = Number.isInteger(target) ? Math.ceil(currentVal) : currentVal.toFixed(1);

            counter.innerText = prefix + formattedVal + suffix;

            if (progress < 1) {
              requestAnimationFrame(updateCounter);
            } else {
              counter.innerText = prefix + target + suffix;
            }
          };
          
          requestAnimationFrame(updateCounter);
          observer.unobserve(counter); // Przestań obserwować po zakończeniu (animuj tylko raz)
        }
      });
    }, {
      root: null,
      rootMargin: '0px',
      threshold: 0.5 // Wyzwól, gdy licznik będzie w 50% widoczny na ekranie
    });

    counters.forEach(counter => counterObserver.observe(counter));
  }
	
	// --- Scroll to Top ---
  const scrollTopBtn = document.querySelector('.scroll-to-top');

  if (scrollTopBtn) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 400) {
        scrollTopBtn.classList.add('is-visible');
      } else {
        scrollTopBtn.classList.remove('is-visible');
      }
    }, { passive: true });

    scrollTopBtn.addEventListener('click', (e) => {
      e.preventDefault();
      // Opcja fallback dla starszych przeglądarek (choć css scroll-behavior robi główną robotę)
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }
	
	// --- Filtrowanie Galerii (Portfolio Filters) ---
  const filterGroups = document.querySelectorAll('.nav-filters');

  filterGroups.forEach(group => {
    const buttons = group.querySelectorAll('button');
    // Szukamy najbliższego kontenera z elementami do filtrowania. 
    // Zakładamy, że elementy mają klasę .filter-item
    const container = group.nextElementSibling; // Zazwyczaj grid z kafelkami jest zaraz pod menu
    if (!container) return;
    
    const items = document.querySelectorAll('.filter-item'); // Szukamy wszystkich kafelków

    buttons.forEach(button => {
      button.addEventListener('click', () => {
        // Zmiana aktywnego przycisku
        buttons.forEach(btn => btn.classList.remove('is-active'));
        button.classList.add('is-active');

        const filterValue = button.getAttribute('data-filter');

        // Filtrowanie elementów
        items.forEach(item => {
          // Usuwamy klasę animacji, żeby móc ją odpalić ponownie
          item.classList.remove('is-animated');
          
          const itemCategory = item.getAttribute('data-category');

          if (filterValue === 'all' || itemCategory === filterValue) {
            item.classList.remove('is-hidden');
            // Delikatne opóźnienie dodania animacji, żeby przeglądarka zdążyła usunąć is-hidden
            setTimeout(() => {
              item.classList.add('is-animated');
            }, 10);
          } else {
            item.classList.add('is-hidden');
          }
        });
      });
    });
  });

  // --- Reading Progress Bar ---
  const progressBar = document.querySelector('.progress-bar');
  if (progressBar) {
    window.addEventListener('scroll', () => {
      const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
      const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      const scrolled = (winScroll / height) * 100;
      progressBar.style.width = scrolled + '%';
    }, { passive: true });
  }
});

// --- Toast Notifications (Global Function) ---
window.showToast = function(message, duration = 3000) {
  let toast = document.getElementById('flexToast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'flexToast';
    toast.className = 'toast-notification';
    document.body.appendChild(toast);
  }
  toast.innerText = message;
  toast.classList.add('is-visible');
  setTimeout(() => toast.classList.remove('is-visible'), duration);
};