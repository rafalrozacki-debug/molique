/**
 * r-lite - ładowanie i inicjalizacja widżetów 
 */

// Inicjalizacja w trybie globalnym (nie wymagamy typu module)

function initBeforeAfter() {
  const setup = () => {
    const sliders = document.querySelectorAll('.before-after-slider');
    sliders.forEach(slider => {
      const control = slider.querySelector('.slider-control');
      if (!control) return;
      control.addEventListener('input', (e) => {
        const value = Number(e.target.value);
        const clamped = Math.min(100, Math.max(0, value));
        slider.style.setProperty('--position', `${clamped}%`);
      });
    });
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setup);
  } else {
    setup();
  }
}

function initWidgets() {
  if (typeof initTilt === 'function') initTilt();
  if (typeof initMagneticButtons === 'function') initMagneticButtons();
  if (typeof initShare === 'function') initShare();
  initBeforeAfter();
}

document.addEventListener('DOMContentLoaded', initWidgets);